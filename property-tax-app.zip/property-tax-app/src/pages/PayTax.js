import React, { useState } from "react";
import { calculatePenalty, getCurrentYear, formatCurrency, formatDate } from "../utils/taxUtils";
import { CreditCard, Search } from "lucide-react";

export default function PayTax({ db, onUpdate }) {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [alert, setAlert] = useState(null);
  const [confirmBill, setConfirmBill] = useState(null);
  const year = getCurrentYear();

  function showAlert(msg, type = "success") {
    setAlert({ msg, type });
    setTimeout(() => setAlert(null), 3500);
  }

  function getProperty(pid) {
    return db.properties.find((p) => p.id === pid);
  }
  function getOwnerName(pid) {
    const p = getProperty(pid);
    if (!p) return "";
    return db.owners.find((o) => o.id === p.owner_id)?.name || "";
  }

  const filtered = db.tax_bills.filter((b) => {
    const prop = getProperty(b.property_id);
    const owner = getOwnerName(b.property_id);
    const matchSearch =
      !search ||
      prop?.address?.toLowerCase().includes(search.toLowerCase()) ||
      owner.toLowerCase().includes(search.toLowerCase()) ||
      String(b.year).includes(search);
    const matchFilter =
      filter === "all" ||
      (filter === "unpaid" && !b.paid) ||
      (filter === "paid" && b.paid) ||
      (filter === "overdue" && !b.paid && b.year < year);
    return matchSearch && matchFilter;
  }).sort((a, b) => (!a.paid ? -1 : 1) || b.year - a.year);

  function handlePay(bill) {
    const penalty = calculatePenalty(bill, year);
    setConfirmBill({ ...bill, penalty });
  }

  function confirmPay() {
    const today = new Date().toISOString().split("T")[0];
    const updated = db.tax_bills.map((b) =>
      b.id === confirmBill.id ? { ...b, paid: true, paid_date: today } : b
    );
    onUpdate({ ...db, tax_bills: updated });
    showAlert(`Payment of ${formatCurrency(confirmBill.amount + confirmBill.penalty)} recorded for bill #${confirmBill.id}.`);
    setConfirmBill(null);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Pay Tax</div>
          <div className="page-subtitle">Mark bills as paid</div>
        </div>
      </div>

      {alert && <div className={`alert ${alert.type}`}>{alert.msg}</div>}

      {/* Filters */}
      <div style={{ display: "flex", gap: 12, marginBottom: 20, flexWrap: "wrap", alignItems: "center" }}>
        <div style={{ position: "relative", flex: 1, minWidth: 200 }}>
          <Search size={14} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--muted)" }} />
          <input
            style={{ paddingLeft: 36 }}
            placeholder="Search by address or owner..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="chip-row" style={{ margin: 0 }}>
          {["all", "unpaid", "paid", "overdue"].map((f) => (
            <button key={f} className={`chip ${filter === f ? "active" : ""}`} onClick={() => setFilter(f)}>
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="table-wrap">
        <div className="table-header-row">
          <span className="table-title">Tax Bills</span>
          <span style={{ color: "var(--muted)", fontSize: 12 }}>{filtered.length} records</span>
        </div>
        {filtered.length === 0 ? (
          <div className="empty-state">
            <CreditCard size={40} />
            <p>No bills found.</p>
          </div>
        ) : (
          <table>
            <thead>
              <tr><th>Bill #</th><th>Property</th><th>Owner</th><th>Year</th><th>Tax Amount</th><th>Penalty</th><th>Total Due</th><th>Status</th><th>Action</th></tr>
            </thead>
            <tbody>
              {filtered.map((b) => {
                const prop = getProperty(b.property_id);
                const penalty = calculatePenalty(b, year);
                const total = b.amount + penalty;
                return (
                  <tr key={b.id}>
                    <td style={{ color: "var(--muted)" }}>#{b.id}</td>
                    <td style={{ fontWeight: 600, maxWidth: 180 }}>{prop?.address || "—"}</td>
                    <td style={{ color: "var(--muted)" }}>{getOwnerName(b.property_id)}</td>
                    <td><span className="badge type">FY{b.year}</span></td>
                    <td>{formatCurrency(b.amount)}</td>
                    <td style={{ color: penalty > 0 ? "var(--red)" : "var(--muted)" }}>
                      {penalty > 0 ? <span style={{ fontWeight: 600 }}>+{formatCurrency(penalty)}</span> : "—"}
                    </td>
                    <td style={{ fontFamily: "var(--font-head)", fontWeight: 800, fontSize: 15, color: b.paid ? "var(--green)" : "var(--accent)" }}>
                      {b.paid ? formatCurrency(b.amount) : formatCurrency(total)}
                    </td>
                    <td>
                      {b.paid ? (
                        <div>
                          <span className="badge paid">✓ Paid</span>
                          <div style={{ fontSize: 11, color: "var(--muted)", marginTop: 4 }}>{formatDate(b.paid_date)}</div>
                        </div>
                      ) : (
                        <span className="badge unpaid">✗ Unpaid</span>
                      )}
                    </td>
                    <td>
                      {!b.paid && (
                        <button className="btn btn-success btn-sm" onClick={() => handlePay(b)}>
                          Pay Now
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Confirm Payment Modal */}
      {confirmBill && (
        <div className="modal-overlay" onClick={() => setConfirmBill(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-title">Confirm Payment</div>
            <div className="bill-detail">
              <div style={{ color: "var(--muted)", fontSize: 12, letterSpacing: 2, textTransform: "uppercase" }}>Bill #{confirmBill.id} — FY{confirmBill.year}</div>
              <div className="bill-amount">{formatCurrency(confirmBill.amount + confirmBill.penalty)}</div>
              <div className="bill-meta">
                <div className="bill-meta-item">
                  <div className="bill-meta-label">Property</div>
                  <div className="bill-meta-value">{getProperty(confirmBill.property_id)?.address || "—"}</div>
                </div>
                <div className="bill-meta-item">
                  <div className="bill-meta-label">Owner</div>
                  <div className="bill-meta-value">{getOwnerName(confirmBill.property_id)}</div>
                </div>
                <div className="bill-meta-item">
                  <div className="bill-meta-label">Tax Amount</div>
                  <div className="bill-meta-value">{formatCurrency(confirmBill.amount)}</div>
                </div>
                {confirmBill.penalty > 0 && (
                  <div className="bill-meta-item">
                    <div className="bill-meta-label">Penalty (12%/yr)</div>
                    <div className="bill-meta-value" style={{ color: "var(--red)" }}>+{formatCurrency(confirmBill.penalty)}</div>
                  </div>
                )}
              </div>
            </div>

            {confirmBill.penalty > 0 && (
              <div className="alert warning">
                ⚠ This bill is {year - confirmBill.year} year(s) overdue. A 12% annual penalty of {formatCurrency(confirmBill.penalty)} has been added.
              </div>
            )}

            <div className="form-actions">
              <button className="btn btn-ghost" onClick={() => setConfirmBill(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={confirmPay}>
                <CreditCard size={14} /> Confirm Payment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
