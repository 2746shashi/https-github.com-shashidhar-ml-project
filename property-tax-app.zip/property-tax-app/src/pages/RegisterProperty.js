import React, { useState } from "react";
import { calculateTax, getCurrentYear, generateBillsForYear } from "../utils/taxUtils";
import { Building2, Plus, User } from "lucide-react";

const PROPERTY_TYPES = ["Residential", "Commercial", "Industrial"];
const USAGE_TYPES = ["Self-Occupied", "Rented"];

export default function RegisterProperty({ db, onUpdate }) {
  const [showForm, setShowForm] = useState(false);
  const [showOwnerForm, setShowOwnerForm] = useState(false);
  const [alert, setAlert] = useState(null);

  const [propForm, setPropForm] = useState({
    owner_id: "",
    address: "",
    type: "Residential",
    area_sqft: "",
    usage: "Self-Occupied",
    year_built: "",
  });

  const [ownerForm, setOwnerForm] = useState({ name: "", email: "", phone: "" });

  function showAlert(msg, type = "success") {
    setAlert({ msg, type });
    setTimeout(() => setAlert(null), 3000);
  }

  function handleAddOwner(e) {
    e.preventDefault();
    if (!ownerForm.name || !ownerForm.email) return showAlert("Name and email required.", "error");
    const newOwner = {
      id: Math.max(...db.owners.map((o) => o.id), 0) + 1,
      ...ownerForm,
    };
    const updated = { ...db, owners: [...db.owners, newOwner] };
    onUpdate(updated);
    setOwnerForm({ name: "", email: "", phone: "" });
    setShowOwnerForm(false);
    showAlert(`Owner "${newOwner.name}" added.`);
  }

  function handleAddProperty(e) {
    e.preventDefault();
    if (!propForm.owner_id || !propForm.address || !propForm.area_sqft) {
      return showAlert("All fields are required.", "error");
    }
    const newProp = {
      id: Math.max(...db.properties.map((p) => p.id), 0) + 1,
      owner_id: parseInt(propForm.owner_id),
      address: propForm.address,
      type: propForm.type,
      area_sqft: parseFloat(propForm.area_sqft),
      usage: propForm.usage,
      year_built: parseInt(propForm.year_built) || new Date().getFullYear(),
    };
    const updatedProps = [...db.properties, newProp];
    // Auto-generate bill for current year
    const year = getCurrentYear();
    const newBills = generateBillsForYear([newProp], db.tax_rates, db.tax_bills, year);
    const updated = {
      ...db,
      properties: updatedProps,
      tax_bills: [...db.tax_bills, ...newBills],
    };
    onUpdate(updated);
    setPropForm({ owner_id: "", address: "", type: "Residential", area_sqft: "", usage: "Self-Occupied", year_built: "" });
    setShowForm(false);
    showAlert(`Property registered & bill of ₹${newBills[0]?.amount || 0} generated for FY${year}.`);
  }

  function getOwnerName(oid) {
    return db.owners.find((o) => o.id === oid)?.name || "—";
  }

  const taxPreview =
    propForm.area_sqft && propForm.type && propForm.usage
      ? calculateTax(
          { area_sqft: parseFloat(propForm.area_sqft), type: propForm.type, usage: propForm.usage },
          db.tax_rates
        )
      : null;

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Properties</div>
          <div className="page-subtitle">{db.properties.length} registered properties</div>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button className="btn btn-ghost" onClick={() => setShowOwnerForm(true)}>
            <User size={15} /> Add Owner
          </button>
          <button className="btn btn-primary" onClick={() => setShowForm(true)}>
            <Plus size={15} /> Register Property
          </button>
        </div>
      </div>

      {alert && <div className={`alert ${alert.type}`}>{alert.msg}</div>}

      {/* Owners table */}
      <div className="table-wrap section-gap">
        <div className="table-header-row">
          <span className="table-title">Owners</span>
          <span style={{ color: "var(--muted)", fontSize: 12 }}>{db.owners.length} total</span>
        </div>
        <table>
          <thead>
            <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Properties</th></tr>
          </thead>
          <tbody>
            {db.owners.map((o) => (
              <tr key={o.id}>
                <td style={{ color: "var(--muted)" }}>#{o.id}</td>
                <td style={{ fontWeight: 600 }}>{o.name}</td>
                <td style={{ color: "var(--muted)" }}>{o.email}</td>
                <td style={{ color: "var(--muted)" }}>{o.phone}</td>
                <td style={{ color: "var(--accent)" }}>
                  {db.properties.filter((p) => p.owner_id === o.id).length}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Properties table */}
      <div className="table-wrap">
        <div className="table-header-row">
          <span className="table-title">All Properties</span>
        </div>
        {db.properties.length === 0 ? (
          <div className="empty-state">
            <Building2 size={40} />
            <p>No properties registered yet.</p>
          </div>
        ) : (
          <table>
            <thead>
              <tr><th>ID</th><th>Address</th><th>Owner</th><th>Type</th><th>Usage</th><th>Area (sqft)</th><th>Built</th></tr>
            </thead>
            <tbody>
              {db.properties.map((p) => (
                <tr key={p.id}>
                  <td style={{ color: "var(--muted)" }}>#{p.id}</td>
                  <td style={{ fontWeight: 600 }}>{p.address}</td>
                  <td style={{ color: "var(--muted)" }}>{getOwnerName(p.owner_id)}</td>
                  <td><span className="badge type">{p.type}</span></td>
                  <td><span className="badge usage">{p.usage}</span></td>
                  <td style={{ fontFamily: "var(--font-head)", fontWeight: 700 }}>{p.area_sqft.toLocaleString()}</td>
                  <td style={{ color: "var(--muted)" }}>{p.year_built}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Add Owner Modal */}
      {showOwnerForm && (
        <div className="modal-overlay" onClick={() => setShowOwnerForm(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-title">Add Property Owner</div>
            <form onSubmit={handleAddOwner}>
              <div className="form-grid">
                <div className="form-group full">
                  <label>Full Name</label>
                  <input value={ownerForm.name} onChange={(e) => setOwnerForm({ ...ownerForm, name: e.target.value })} placeholder="e.g. Arjun Reddy" required />
                </div>
                <div className="form-group">
                  <label>Email</label>
                  <input type="email" value={ownerForm.email} onChange={(e) => setOwnerForm({ ...ownerForm, email: e.target.value })} placeholder="email@example.com" required />
                </div>
                <div className="form-group">
                  <label>Phone</label>
                  <input value={ownerForm.phone} onChange={(e) => setOwnerForm({ ...ownerForm, phone: e.target.value })} placeholder="10-digit number" />
                </div>
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-ghost" onClick={() => setShowOwnerForm(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Add Owner</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Property Modal */}
      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-title">Register New Property</div>
            <form onSubmit={handleAddProperty}>
              <div className="form-grid">
                <div className="form-group full">
                  <label>Owner</label>
                  <select value={propForm.owner_id} onChange={(e) => setPropForm({ ...propForm, owner_id: e.target.value })} required>
                    <option value="">Select owner...</option>
                    {db.owners.map((o) => (
                      <option key={o.id} value={o.id}>{o.name}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group full">
                  <label>Address</label>
                  <input value={propForm.address} onChange={(e) => setPropForm({ ...propForm, address: e.target.value })} placeholder="Full property address" required />
                </div>
                <div className="form-group">
                  <label>Property Type</label>
                  <select value={propForm.type} onChange={(e) => setPropForm({ ...propForm, type: e.target.value })}>
                    {PROPERTY_TYPES.map((t) => <option key={t}>{t}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Usage</label>
                  <select value={propForm.usage} onChange={(e) => setPropForm({ ...propForm, usage: e.target.value })}>
                    {USAGE_TYPES.map((t) => <option key={t}>{t}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Area (sqft)</label>
                  <input type="number" value={propForm.area_sqft} onChange={(e) => setPropForm({ ...propForm, area_sqft: e.target.value })} placeholder="e.g. 1200" min="1" required />
                </div>
                <div className="form-group">
                  <label>Year Built</label>
                  <input type="number" value={propForm.year_built} onChange={(e) => setPropForm({ ...propForm, year_built: e.target.value })} placeholder={new Date().getFullYear()} min="1900" />
                </div>
              </div>

              {taxPreview !== null && (
                <div className="alert warning" style={{ marginTop: 16 }}>
                  💡 Estimated annual tax: <strong>₹{taxPreview.toLocaleString()}</strong> ({propForm.area_sqft} sqft × ₹
                  {db.tax_rates.find((r) => r.property_type === propForm.type && r.usage === propForm.usage)?.rate_per_sqft || 0}/sqft)
                </div>
              )}

              <div className="form-actions">
                <button type="button" className="btn btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Register & Generate Bill</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
