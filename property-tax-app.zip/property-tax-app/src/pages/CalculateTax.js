import React, { useState } from "react";
import { calculateTax, calculatePenalty, getCurrentYear, formatCurrency, generateBillsForYear } from "../utils/taxUtils";
import { Calculator, RefreshCw } from "lucide-react";

export default function CalculateTax({ db, onUpdate }) {
  const [alert, setAlert] = useState(null);
  const year = getCurrentYear();

  function showAlert(msg, type = "success") {
    setAlert({ msg, type });
    setTimeout(() => setAlert(null), 3500);
  }

  function generateAllBills() {
    const newBills = generateBillsForYear(db.properties, db.tax_rates, db.tax_bills, year);
    if (newBills.length === 0) {
      return showAlert(`All bills for FY${year} already exist.`, "warning");
    }
    onUpdate({ ...db, tax_bills: [...db.tax_bills, ...newBills] });
    showAlert(`Generated ${newBills.length} new bill(s) for FY${year}.`);
  }

  function getOwnerName(pid) {
    const p = db.properties.find((x) => x.id === pid);
    if (!p) return "—";
    return db.owners.find((x) => x.id === p.owner_id)?.name || "—";
  }

  function getProperty(pid) {
    return db.properties.find((x) => x.id === pid);
  }

  function getRate(prop) {
    return db.tax_rates.find((r) => r.property_type === prop.type && r.usage === prop.usage);
  }

  const allBills = db.tax_bills.sort((a, b) => b.year - a.year || a.property_id - b.property_id);

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Tax Calculator</div>
          <div className="page-subtitle">View and generate annual tax bills</div>
        </div>
        <button className="btn btn-primary" onClick={generateAllBills}>
          <RefreshCw size={14} /> Generate FY{year} Bills
        </button>
      </div>

      {alert && <div className={`alert ${alert.type}`}>{alert.msg}</div>}

      {/* Tax rates reference */}
      <div className="table-wrap section-gap">
        <div className="table-header-row">
          <span className="table-title">Current Tax Rates</span>
          <span style={{ color: "var(--muted)", fontSize: 12 }}>Rate per sqft per year</span>
        </div>
        <table>
          <thead>
            <tr><th>Property Type</th><th>Usage</th><th>Rate / sqft</th><th>Example (1000 sqft)</th></tr>
          </thead>
          <tbody>
            {db.tax_rates.map((r) => (
              <tr key={r.id}>
                <td><span className="badge type">{r.property_type}</span></td>
                <td><span className="badge usage">{r.usage}</span></td>
                <td style={{ fontFamily: "var(--font-head)", fontWeight: 700, color: "var(--accent)", fontSize: 16 }}>₹{r.rate_per_sqft}</td>
                <td style={{ color: "var(--muted)" }}>{formatCurrency(1000 * r.rate_per_sqft)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Property-wise tax breakdown */}
      <div className="table-wrap section-gap">
        <div className="table-header-row">
          <span className="table-title">Property-wise Tax Breakdown</span>
        </div>
        <table>
          <thead>
            <tr><th>Property</th><th>Owner</th><th>Type / Usage</th><th>Area</th><th>Rate</th><th>Annual Tax</th></tr>
          </thead>
          <tbody>
            {db.properties.map((p) => {
              const rate = getRate(p);
              const tax = calculateTax(p, db.tax_rates);
              return (
                <tr key={p.id}>
                  <td style={{ fontWeight: 600, maxWidth: 220 }}>{p.address}</td>
                  <td style={{ color: "var(--muted)" }}>{getOwnerName(p.id)}</td>
                  <td>
                    <div style={{ display: "flex", gap: 6 }}>
                      <span className="badge type">{p.type}</span>
                      <span className="badge usage">{p.usage}</span>
                    </div>
                  </td>
                  <td style={{ fontFamily: "var(--font-head)", fontWeight: 700 }}>{p.area_sqft.toLocaleString()} sqft</td>
                  <td style={{ color: "var(--muted)" }}>₹{rate?.rate_per_sqft || "N/A"}/sqft</td>
                  <td style={{ fontFamily: "var(--font-head)", fontWeight: 800, color: "var(--accent)", fontSize: 17 }}>{formatCurrency(tax)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* All tax bills */}
      <div className="table-wrap">
        <div className="table-header-row">
          <span className="table-title">All Tax Bills</span>
          <span style={{ color: "var(--muted)", fontSize: 12 }}>{allBills.length} total</span>
        </div>
        {allBills.length === 0 ? (
          <div className="empty-state">
            <Calculator size={40} />
            <p>No bills generated yet. Click "Generate FY{year} Bills" to start.</p>
          </div>
        ) : (
          <table>
            <thead>
              <tr><th>Bill #</th><th>Property</th><th>Owner</th><th>Year</th><th>Amount</th><th>Penalty</th><th>Status</th></tr>
            </thead>
            <tbody>
              {allBills.map((b) => {
                const prop = getProperty(b.property_id);
                const penalty = calculatePenalty(b, year);
                return (
                  <tr key={b.id}>
                    <td style={{ color: "var(--muted)" }}>#{b.id}</td>
                    <td style={{ maxWidth: 200 }}>{prop?.address || "—"}</td>
                    <td style={{ color: "var(--muted)" }}>{getOwnerName(b.property_id)}</td>
                    <td><span className="badge type">FY{b.year}</span></td>
                    <td style={{ fontFamily: "var(--font-head)", fontWeight: 700 }}>{formatCurrency(b.amount)}</td>
                    <td style={{ color: penalty > 0 ? "var(--red)" : "var(--muted)" }}>
                      {penalty > 0 ? formatCurrency(penalty) : "—"}
                    </td>
                    <td>
                      <span className={`badge ${b.paid ? "paid" : "unpaid"}`}>
                        {b.paid ? "✓ Paid" : "✗ Unpaid"}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
