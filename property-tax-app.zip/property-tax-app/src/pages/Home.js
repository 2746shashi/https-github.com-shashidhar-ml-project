import React from "react";
import { formatCurrency, calculatePenalty, getCurrentYear } from "../utils/taxUtils";

export default function Home({ db }) {
  const year = getCurrentYear();
  const bills = db.tax_bills;
  const properties = db.properties;
  const owners = db.owners;

  const totalBills = bills.filter((b) => b.year === year);
  const paidBills = totalBills.filter((b) => b.paid);
  const unpaidBills = totalBills.filter((b) => !b.paid);
  const totalAmount = totalBills.reduce((s, b) => s + b.amount, 0);
  const collectedAmount = paidBills.reduce((s, b) => s + b.amount, 0);
  const pendingAmount = unpaidBills.reduce((s, b) => s + b.amount, 0);
  const overdueOld = bills.filter((b) => !b.paid && b.year < year);
  const totalPenalty = overdueOld.reduce((s, b) => s + calculatePenalty(b, year), 0);
  const collectionPct = totalAmount > 0 ? Math.round((collectedAmount / totalAmount) * 100) : 0;

  // Recent activity
  const recentPaid = bills
    .filter((b) => b.paid && b.paid_date)
    .sort((a, b) => new Date(b.paid_date) - new Date(a.paid_date))
    .slice(0, 5);

  function getPropAddress(pid) {
    const p = properties.find((x) => x.id === pid);
    return p ? p.address : "—";
  }
  function getOwnerName(pid) {
    const p = properties.find((x) => x.id === pid);
    if (!p) return "—";
    const o = owners.find((x) => x.id === p.owner_id);
    return o ? o.name : "—";
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Dashboard</div>
          <div className="page-subtitle">FY {year} — Tax Overview</div>
        </div>
      </div>

      <div className="stats-row">
        <div className="stat-card">
          <div className="stat-label">Total Properties</div>
          <div className="stat-value accent">{properties.length}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Total Demand</div>
          <div className="stat-value">{formatCurrency(totalAmount)}</div>
        </div>
        <div className="stat-card green">
          <div className="stat-label">Collected</div>
          <div className="stat-value green">{formatCurrency(collectedAmount)}</div>
        </div>
        <div className="stat-card red">
          <div className="stat-label">Pending</div>
          <div className="stat-value red">{formatCurrency(pendingAmount)}</div>
        </div>
        <div className="stat-card red">
          <div className="stat-label">Penalty Due</div>
          <div className="stat-value red">{formatCurrency(totalPenalty)}</div>
        </div>
      </div>

      {/* Collection Progress */}
      <div className="table-wrap section-gap" style={{ padding: "24px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <span style={{ fontFamily: "var(--font-head)", fontWeight: 700 }}>Collection Progress — FY {year}</span>
          <span style={{ color: "var(--accent)", fontWeight: 700, fontSize: 18, fontFamily: "var(--font-head)" }}>{collectionPct}%</span>
        </div>
        <div className="progress-bar">
          <div className="progress-fill" style={{ width: `${collectionPct}%` }} />
        </div>
        <div style={{ display: "flex", gap: 24, marginTop: 12 }}>
          <span style={{ color: "var(--muted)", fontSize: 12 }}>✓ Paid: {paidBills.length} properties</span>
          <span style={{ color: "var(--muted)", fontSize: 12 }}>✗ Pending: {unpaidBills.length} properties</span>
          <span style={{ color: "var(--muted)", fontSize: 12 }}>⚠ Overdue (prev yrs): {overdueOld.length}</span>
        </div>
      </div>

      {/* By type breakdown */}
      <div className="stats-row section-gap">
        {["Residential", "Commercial", "Industrial"].map((type) => {
          const typeProps = properties.filter((p) => p.type === type);
          const typeBills = bills.filter((b) =>
            typeProps.some((p) => p.id === b.property_id) && b.year === year
          );
          const typePaid = typeBills.filter((b) => b.paid).length;
          return (
            <div key={type} className="report-card">
              <h3>{type}</h3>
              <div className="report-row">
                <span className="report-row-label">Properties</span>
                <span className="report-row-value">{typeProps.length}</span>
              </div>
              <div className="report-row">
                <span className="report-row-label">Bills FY{year}</span>
                <span className="report-row-value">{typeBills.length}</span>
              </div>
              <div className="report-row">
                <span className="report-row-label">Paid</span>
                <span className="report-row-value" style={{ color: "var(--green)" }}>{typePaid}</span>
              </div>
              <div className="report-row">
                <span className="report-row-label">Unpaid</span>
                <span className="report-row-value" style={{ color: "var(--red)" }}>{typeBills.length - typePaid}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Payments */}
      <div className="table-wrap">
        <div className="table-header-row">
          <span className="table-title">Recent Payments</span>
        </div>
        {recentPaid.length === 0 ? (
          <div className="empty-state"><p>No payments recorded yet.</p></div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Property</th>
                <th>Owner</th>
                <th>Year</th>
                <th>Amount</th>
                <th>Paid On</th>
              </tr>
            </thead>
            <tbody>
              {recentPaid.map((b) => (
                <tr key={b.id}>
                  <td style={{ color: "var(--text)" }}>{getPropAddress(b.property_id)}</td>
                  <td style={{ color: "var(--muted)" }}>{getOwnerName(b.property_id)}</td>
                  <td><span className="badge type">FY{b.year}</span></td>
                  <td style={{ color: "var(--green)", fontFamily: "var(--font-head)", fontWeight: 700 }}>{formatCurrency(b.amount)}</td>
                  <td style={{ color: "var(--muted)" }}>{new Date(b.paid_date).toLocaleDateString("en-IN")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
