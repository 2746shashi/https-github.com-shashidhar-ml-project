import React, { useState } from "react";
import { formatCurrency, formatDate, getCurrentYear } from "../utils/taxUtils";
import { History } from "lucide-react";

export default function PaymentHistory({ db }) {
  const [yearFilter, setYearFilter] = useState("all");
  const year = getCurrentYear();

  const paidBills = db.tax_bills.filter((b) => b.paid)
    .sort((a, b) => new Date(b.paid_date) - new Date(a.paid_date));

  const years = [...new Set(db.tax_bills.map((b) => b.year))].sort((a, b) => b - a);

  const filtered = yearFilter === "all" ? paidBills : paidBills.filter((b) => b.year === parseInt(yearFilter));

  function getProperty(pid) { return db.properties.find((p) => p.id === pid); }
  function getOwnerName(pid) {
    const p = getProperty(pid);
    if (!p) return "—";
    return db.owners.find((o) => o.id === p.owner_id)?.name || "—";
  }

  const totalCollected = filtered.reduce((s, b) => s + b.amount, 0);

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Payment History</div>
          <div className="page-subtitle">{paidBills.length} payments recorded</div>
        </div>
      </div>

      {/* Summary */}
      <div className="stats-row section-gap">
        <div className="stat-card green">
          <div className="stat-label">Total Collected</div>
          <div className="stat-value green">{formatCurrency(paidBills.reduce((s, b) => s + b.amount, 0))}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Payments Count</div>
          <div className="stat-value accent">{paidBills.length}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">FY{year} Collected</div>
          <div className="stat-value">{formatCurrency(paidBills.filter((b) => b.year === year).reduce((s, b) => s + b.amount, 0))}</div>
        </div>
      </div>

      {/* Year filter */}
      <div className="chip-row">
        <button className={`chip ${yearFilter === "all" ? "active" : ""}`} onClick={() => setYearFilter("all")}>All Years</button>
        {years.map((y) => (
          <button key={y} className={`chip ${yearFilter === y ? "active" : ""}`} onClick={() => setYearFilter(y)}>FY{y}</button>
        ))}
      </div>

      <div className="table-wrap">
        <div className="table-header-row">
          <span className="table-title">
            {yearFilter === "all" ? "All Payments" : `FY${yearFilter} Payments`}
          </span>
          <span style={{ color: "var(--green)", fontFamily: "var(--font-head)", fontWeight: 700 }}>
            {formatCurrency(totalCollected)} collected
          </span>
        </div>
        {filtered.length === 0 ? (
          <div className="empty-state">
            <History size={40} />
            <p>No payments found.</p>
          </div>
        ) : (
          <table>
            <thead>
              <tr><th>Bill #</th><th>Paid On</th><th>Property</th><th>Owner</th><th>Year</th><th>Amount</th></tr>
            </thead>
            <tbody>
              {filtered.map((b) => {
                const prop = getProperty(b.property_id);
                return (
                  <tr key={b.id}>
                    <td style={{ color: "var(--muted)" }}>#{b.id}</td>
                    <td style={{ color: "var(--green)" }}>{formatDate(b.paid_date)}</td>
                    <td style={{ fontWeight: 600, maxWidth: 200 }}>{prop?.address || "—"}</td>
                    <td style={{ color: "var(--muted)" }}>{getOwnerName(b.property_id)}</td>
                    <td><span className="badge type">FY{b.year}</span></td>
                    <td style={{ fontFamily: "var(--font-head)", fontWeight: 800, color: "var(--green)", fontSize: 15 }}>
                      {formatCurrency(b.amount)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
