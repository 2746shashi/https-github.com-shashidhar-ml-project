import React, { useState } from "react";
import { formatCurrency, calculatePenalty, getCurrentYear } from "../utils/taxUtils";
import { Settings, RotateCcw } from "lucide-react";
import { resetDB } from "../data/db";

const PROPERTY_TYPES = ["Residential", "Commercial", "Industrial"];
const USAGE_TYPES = ["Self-Occupied", "Rented"];

export default function Admin({ db, onUpdate }) {
  const [alert, setAlert] = useState(null);
  const [editRate, setEditRate] = useState(null);
  const [showAddRate, setShowAddRate] = useState(false);
  const [newRate, setNewRate] = useState({ property_type: "Residential", usage: "Self-Occupied", rate_per_sqft: "" });
  const year = getCurrentYear();

  function showAlert(msg, type = "success") {
    setAlert({ msg, type });
    setTimeout(() => setAlert(null), 3500);
  }

  function handleUpdateRate(e) {
    e.preventDefault();
    const updated = db.tax_rates.map((r) => r.id === editRate.id ? { ...editRate } : r);
    onUpdate({ ...db, tax_rates: updated });
    showAlert("Tax rate updated successfully.");
    setEditRate(null);
  }

  function handleAddRate(e) {
    e.preventDefault();
    if (!newRate.rate_per_sqft) return showAlert("Rate is required.", "error");
    const exists = db.tax_rates.find((r) => r.property_type === newRate.property_type && r.usage === newRate.usage);
    if (exists) return showAlert("Rate for this type/usage already exists.", "error");
    const id = Math.max(...db.tax_rates.map((r) => r.id), 0) + 1;
    onUpdate({ ...db, tax_rates: [...db.tax_rates, { ...newRate, id, rate_per_sqft: parseFloat(newRate.rate_per_sqft) }] });
    showAlert("New rate added.");
    setShowAddRate(false);
    setNewRate({ property_type: "Residential", usage: "Self-Occupied", rate_per_sqft: "" });
  }

  function handleDeleteRate(id) {
    if (!window.confirm("Delete this rate?")) return;
    onUpdate({ ...db, tax_rates: db.tax_rates.filter((r) => r.id !== id) });
    showAlert("Rate deleted.");
  }

  function handleReset() {
    if (!window.confirm("Reset ALL data to demo defaults? This cannot be undone.")) return;
    const fresh = resetDB();
    onUpdate(fresh);
    showAlert("Data reset to demo defaults.");
  }

  // Reports
  const bills = db.tax_bills;
  const totalDemand = bills.reduce((s, b) => s + b.amount, 0);
  const totalCollected = bills.filter((b) => b.paid).reduce((s, b) => s + b.amount, 0);
  const totalPending = bills.filter((b) => !b.paid).reduce((s, b) => s + b.amount, 0);
  const totalPenalty = bills.filter((b) => !b.paid).reduce((s, b) => s + calculatePenalty(b, year), 0);

  const byType = PROPERTY_TYPES.map((type) => {
    const props = db.properties.filter((p) => p.type === type);
    const typeBills = bills.filter((b) => props.some((p) => p.id === b.property_id));
    const paid = typeBills.filter((b) => b.paid).reduce((s, b) => s + b.amount, 0);
    const pending = typeBills.filter((b) => !b.paid).reduce((s, b) => s + b.amount, 0);
    return { type, count: props.length, paid, pending };
  });

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Admin Panel</div>
          <div className="page-subtitle">Tax rate management & reports</div>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button className="btn btn-ghost" onClick={handleReset} title="Reset to demo data">
            <RotateCcw size={14} /> Reset Data
          </button>
          <button className="btn btn-primary" onClick={() => setShowAddRate(true)}>
            <Settings size={14} /> Add Rate
          </button>
        </div>
      </div>

      {alert && <div className={`alert ${alert.type}`}>{alert.msg}</div>}

      {/* Reports */}
      <div className="report-grid section-gap">
        <div className="report-card">
          <h3>Overall Summary</h3>
          <div className="report-row">
            <span className="report-row-label">Total Demand</span>
            <span className="report-row-value">{formatCurrency(totalDemand)}</span>
          </div>
          <div className="report-row">
            <span className="report-row-label">Total Collected</span>
            <span className="report-row-value" style={{ color: "var(--green)" }}>{formatCurrency(totalCollected)}</span>
          </div>
          <div className="report-row">
            <span className="report-row-label">Total Pending</span>
            <span className="report-row-value" style={{ color: "var(--red)" }}>{formatCurrency(totalPending)}</span>
          </div>
          <div className="report-row">
            <span className="report-row-label">Penalty Outstanding</span>
            <span className="report-row-value" style={{ color: "var(--red)" }}>{formatCurrency(totalPenalty)}</span>
          </div>
          <div className="report-row">
            <span className="report-row-label">Collection Rate</span>
            <span className="report-row-value" style={{ color: "var(--accent)" }}>
              {totalDemand > 0 ? Math.round((totalCollected / totalDemand) * 100) : 0}%
            </span>
          </div>
        </div>

        <div className="report-card">
          <h3>By Property Type</h3>
          {byType.map(({ type, count, paid, pending }) => (
            <div key={type} className="report-row">
              <div>
                <div style={{ fontWeight: 600 }}>{type}</div>
                <div style={{ fontSize: 11, color: "var(--muted)" }}>{count} properties</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ color: "var(--green)", fontSize: 13 }}>✓ {formatCurrency(paid)}</div>
                <div style={{ color: "var(--red)", fontSize: 12 }}>✗ {formatCurrency(pending)}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Tax Rates */}
      <div className="table-wrap">
        <div className="table-header-row">
          <span className="table-title">Tax Rates Configuration</span>
          <span style={{ color: "var(--muted)", fontSize: 12 }}>Click Edit to modify rates</span>
        </div>
        <table>
          <thead>
            <tr><th>ID</th><th>Property Type</th><th>Usage</th><th>Rate per sqft (₹)</th><th>Actions</th></tr>
          </thead>
          <tbody>
            {db.tax_rates.map((r) => (
              <tr key={r.id}>
                <td style={{ color: "var(--muted)" }}>#{r.id}</td>
                <td><span className="badge type">{r.property_type}</span></td>
                <td><span className="badge usage">{r.usage}</span></td>
                <td style={{ fontFamily: "var(--font-head)", fontWeight: 800, color: "var(--accent)", fontSize: 18 }}>₹{r.rate_per_sqft}</td>
                <td>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button className="btn btn-ghost btn-sm" onClick={() => setEditRate({ ...r })}>Edit</button>
                    <button className="btn btn-danger btn-sm" onClick={() => handleDeleteRate(r.id)}>Delete</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Edit Rate Modal */}
      {editRate && (
        <div className="modal-overlay" onClick={() => setEditRate(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-title">Edit Tax Rate</div>
            <form onSubmit={handleUpdateRate}>
              <div className="form-grid">
                <div className="form-group">
                  <label>Property Type</label>
                  <select value={editRate.property_type} onChange={(e) => setEditRate({ ...editRate, property_type: e.target.value })}>
                    {PROPERTY_TYPES.map((t) => <option key={t}>{t}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Usage</label>
                  <select value={editRate.usage} onChange={(e) => setEditRate({ ...editRate, usage: e.target.value })}>
                    {USAGE_TYPES.map((t) => <option key={t}>{t}</option>)}
                  </select>
                </div>
                <div className="form-group full">
                  <label>Rate per sqft (₹)</label>
                  <input type="number" step="0.01" min="0" value={editRate.rate_per_sqft}
                    onChange={(e) => setEditRate({ ...editRate, rate_per_sqft: parseFloat(e.target.value) })} required />
                </div>
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-ghost" onClick={() => setEditRate(null)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Update Rate</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Rate Modal */}
      {showAddRate && (
        <div className="modal-overlay" onClick={() => setShowAddRate(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-title">Add New Tax Rate</div>
            <form onSubmit={handleAddRate}>
              <div className="form-grid">
                <div className="form-group">
                  <label>Property Type</label>
                  <select value={newRate.property_type} onChange={(e) => setNewRate({ ...newRate, property_type: e.target.value })}>
                    {PROPERTY_TYPES.map((t) => <option key={t}>{t}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Usage</label>
                  <select value={newRate.usage} onChange={(e) => setNewRate({ ...newRate, usage: e.target.value })}>
                    {USAGE_TYPES.map((t) => <option key={t}>{t}</option>)}
                  </select>
                </div>
                <div className="form-group full">
                  <label>Rate per sqft (₹)</label>
                  <input type="number" step="0.01" min="0" value={newRate.rate_per_sqft}
                    onChange={(e) => setNewRate({ ...newRate, rate_per_sqft: e.target.value })} required />
                </div>
              </div>
              <div className="form-actions">
                <button type="button" className="btn btn-ghost" onClick={() => setShowAddRate(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Add Rate</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
