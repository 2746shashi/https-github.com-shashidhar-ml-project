import React, { useState, useEffect } from "react";
import "./App.css";
import { loadDB, saveDB } from "./data/db";
import Home from "./pages/Home";
import RegisterProperty from "./pages/RegisterProperty";
import CalculateTax from "./pages/CalculateTax";
import PayTax from "./pages/PayTax";
import PaymentHistory from "./pages/PaymentHistory";
import Admin from "./pages/Admin";

import {
  LayoutDashboard,
  Building2,
  Calculator,
  CreditCard,
  History,
  Settings,
} from "lucide-react";

const NAV = [
  { id: "home", label: "Dashboard", icon: LayoutDashboard, section: "main" },
  { id: "register", label: "Register Property", icon: Building2, section: "main" },
  { id: "calculate", label: "Calculate Tax", icon: Calculator, section: "main" },
  { id: "pay", label: "Pay Tax", icon: CreditCard, section: "main" },
  { id: "history", label: "Payment History", icon: History, section: "main" },
  { id: "admin", label: "Admin", icon: Settings, section: "admin" },
];

export default function App() {
  const [page, setPage] = useState("home");
  const [db, setDb] = useState(() => loadDB());

  function handleUpdate(newDb) {
    setDb(newDb);
    saveDB(newDb);
  }

  const pageProps = { db, onUpdate: handleUpdate };

  const pages = {
    home: <Home {...pageProps} />,
    register: <RegisterProperty {...pageProps} />,
    calculate: <CalculateTax {...pageProps} />,
    pay: <PayTax {...pageProps} />,
    history: <PaymentHistory {...pageProps} />,
    admin: <Admin {...pageProps} />,
  };

  return (
    <div className="app-layout">
      <aside className="sidebar">
        <div className="sidebar-logo">
          <h1>PropertyTax</h1>
          <span>Management System</span>
        </div>
        <nav className="sidebar-nav">
          <div className="nav-section-label">Main</div>
          {NAV.filter((n) => n.section === "main").map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                className={`nav-item ${page === item.id ? "active" : ""}`}
                onClick={() => setPage(item.id)}
              >
                <Icon size={16} />
                {item.label}
              </button>
            );
          })}
          <div className="nav-section-label" style={{ marginTop: 16 }}>System</div>
          {NAV.filter((n) => n.section === "admin").map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                className={`nav-item ${page === item.id ? "active" : ""}`}
                onClick={() => setPage(item.id)}
              >
                <Icon size={16} />
                {item.label}
              </button>
            );
          })}
        </nav>
        <div style={{ padding: "16px 20px", borderTop: "1px solid var(--border)", color: "var(--muted)", fontSize: 11 }}>
          v1.0 · {new Date().getFullYear()}
        </div>
      </aside>
      <main className="main-content">
        {pages[page]}
      </main>
    </div>
  );
}
