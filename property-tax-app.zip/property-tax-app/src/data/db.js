// Initial seed data
export const initialData = {
  owners: [
    { id: 1, name: "Rajesh Kumar", email: "rajesh@email.com", phone: "9876543210" },
    { id: 2, name: "Priya Sharma", email: "priya@email.com", phone: "9123456789" },
  ],
  properties: [
    { id: 1, owner_id: 1, address: "12, MG Road, Bengaluru", type: "Residential", area_sqft: 1200, usage: "Self-Occupied", year_built: 2010 },
    { id: 2, owner_id: 1, address: "45, Brigade Road, Bengaluru", type: "Commercial", area_sqft: 800, usage: "Rented", year_built: 2005 },
    { id: 3, owner_id: 2, address: "7, Jayanagar 4th Block, Bengaluru", type: "Residential", area_sqft: 950, usage: "Rented", year_built: 2015 },
  ],
  tax_rates: [
    { id: 1, property_type: "Residential", usage: "Self-Occupied", rate_per_sqft: 2.5 },
    { id: 2, property_type: "Residential", usage: "Rented", rate_per_sqft: 3.5 },
    { id: 3, property_type: "Commercial", usage: "Self-Occupied", rate_per_sqft: 5.0 },
    { id: 4, property_type: "Commercial", usage: "Rented", rate_per_sqft: 7.5 },
    { id: 5, property_type: "Industrial", usage: "Self-Occupied", rate_per_sqft: 4.0 },
    { id: 6, property_type: "Industrial", usage: "Rented", rate_per_sqft: 6.0 },
  ],
  tax_bills: [
    { id: 1, property_id: 1, year: 2024, amount: 3000, paid: true, paid_date: "2024-03-15" },
    { id: 2, property_id: 2, year: 2024, amount: 6000, paid: false, paid_date: null },
    { id: 3, property_id: 3, year: 2024, amount: 3325, paid: true, paid_date: "2024-04-10" },
    { id: 4, property_id: 1, year: 2025, amount: 3000, paid: false, paid_date: null },
    { id: 5, property_id: 2, year: 2025, amount: 6000, paid: false, paid_date: null },
  ],
};

const DB_KEY = "property_tax_db";

export function loadDB() {
  try {
    const saved = localStorage.getItem(DB_KEY);
    return saved ? JSON.parse(saved) : { ...initialData };
  } catch {
    return { ...initialData };
  }
}

export function saveDB(db) {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
}

export function resetDB() {
  localStorage.setItem(DB_KEY, JSON.stringify(initialData));
  return { ...initialData };
}
