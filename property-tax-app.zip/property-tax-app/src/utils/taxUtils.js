export function calculateTax(property, tax_rates) {
  const rate = tax_rates.find(
    (r) => r.property_type === property.type && r.usage === property.usage
  );
  if (!rate) return 0;
  return Math.round(property.area_sqft * rate.rate_per_sqft);
}

export function calculatePenalty(bill, currentYear) {
  if (bill.paid) return 0;
  const yearsOverdue = currentYear - bill.year;
  if (yearsOverdue <= 0) return 0;
  // 12% annual penalty
  return Math.round(bill.amount * 0.12 * yearsOverdue);
}

export function getCurrentYear() {
  return new Date().getFullYear();
}

export function generateBillsForYear(properties, tax_rates, existing_bills, year) {
  const newBills = [];
  let nextId = Math.max(...existing_bills.map((b) => b.id), 0) + 1;
  for (const prop of properties) {
    const alreadyExists = existing_bills.find(
      (b) => b.property_id === prop.id && b.year === year
    );
    if (!alreadyExists) {
      const amount = calculateTax(prop, tax_rates);
      newBills.push({
        id: nextId++,
        property_id: prop.id,
        year,
        amount,
        paid: false,
        paid_date: null,
      });
    }
  }
  return newBills;
}

export function formatCurrency(amount) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(dateStr) {
  if (!dateStr) return "—";
  return new Date(dateStr).toLocaleDateString("en-IN", {
    day: "2-digit", month: "short", year: "numeric",
  });
}
